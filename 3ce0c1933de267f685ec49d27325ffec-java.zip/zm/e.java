package zm;

import com.mobvoi.companion.aw.R;
/* loaded from: classes2.dex */
public final class e {
    public static final int A = 26;
    public static final int B = 27;
    public static final int C = 28;
    public static final int D = 29;
    public static final int E = 30;
    public static final int F = 31;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f37637a = {R.attr.cropAspectRatioX, R.attr.cropAspectRatioY, R.attr.cropAutoZoomEnabled, R.attr.cropBackgroundColor, R.attr.cropBorderCornerColor, R.attr.cropBorderCornerLength, R.attr.cropBorderCornerOffset, R.attr.cropBorderCornerThickness, R.attr.cropBorderLineColor, R.attr.cropBorderLineThickness, R.attr.cropFixAspectRatio, R.attr.cropFlipHorizontally, R.attr.cropFlipVertically, R.attr.cropGuidelines, R.attr.cropGuidelinesColor, R.attr.cropGuidelinesThickness, R.attr.cropInitialCropWindowPaddingRatio, R.attr.cropMaxCropResultHeightPX, R.attr.cropMaxCropResultWidthPX, R.attr.cropMaxZoom, R.attr.cropMinCropResultHeightPX, R.attr.cropMinCropResultWidthPX, R.attr.cropMinCropWindowHeight, R.attr.cropMinCropWindowWidth, R.attr.cropMultiTouchEnabled, R.attr.cropSaveBitmapToInstanceState, R.attr.cropScaleType, R.attr.cropShape, R.attr.cropShowCropOverlay, R.attr.cropShowProgressBar, R.attr.cropSnapRadius, R.attr.cropTouchRadius};

    /* renamed from: b  reason: collision with root package name */
    public static final int f37638b = 0;

    /* renamed from: c  reason: collision with root package name */
    public static final int f37639c = 1;

    /* renamed from: d  reason: collision with root package name */
    public static final int f37640d = 2;

    /* renamed from: e  reason: collision with root package name */
    public static final int f37641e = 3;

    /* renamed from: f  reason: collision with root package name */
    public static final int f37642f = 4;

    /* renamed from: g  reason: collision with root package name */
    public static final int f37643g = 5;

    /* renamed from: h  reason: collision with root package name */
    public static final int f37644h = 6;

    /* renamed from: i  reason: collision with root package name */
    public static final int f37645i = 7;

    /* renamed from: j  reason: collision with root package name */
    public static final int f37646j = 8;

    /* renamed from: k  reason: collision with root package name */
    public static final int f37647k = 9;

    /* renamed from: l  reason: collision with root package name */
    public static final int f37648l = 10;

    /* renamed from: m  reason: collision with root package name */
    public static final int f37649m = 11;

    /* renamed from: n  reason: collision with root package name */
    public static final int f37650n = 13;

    /* renamed from: o  reason: collision with root package name */
    public static final int f37651o = 14;

    /* renamed from: p  reason: collision with root package name */
    public static final int f37652p = 15;

    /* renamed from: q  reason: collision with root package name */
    public static final int f37653q = 16;

    /* renamed from: r  reason: collision with root package name */
    public static final int f37654r = 17;

    /* renamed from: s  reason: collision with root package name */
    public static final int f37655s = 18;

    /* renamed from: t  reason: collision with root package name */
    public static final int f37656t = 19;

    /* renamed from: u  reason: collision with root package name */
    public static final int f37657u = 20;

    /* renamed from: v  reason: collision with root package name */
    public static final int f37658v = 21;

    /* renamed from: w  reason: collision with root package name */
    public static final int f37659w = 22;

    /* renamed from: x  reason: collision with root package name */
    public static final int f37660x = 23;

    /* renamed from: y  reason: collision with root package name */
    public static final int f37661y = 24;

    /* renamed from: z  reason: collision with root package name */
    public static final int f37662z = 25;
}
