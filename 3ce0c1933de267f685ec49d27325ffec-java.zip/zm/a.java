package zm;
/* loaded from: classes2.dex */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final int f37633a = 2131427336;

    /* renamed from: b  reason: collision with root package name */
    public static final int f37634b = 2131427337;

    /* renamed from: c  reason: collision with root package name */
    public static final int f37635c = 2131427342;

    /* renamed from: d  reason: collision with root package name */
    public static final int f37636d = 2131427789;

    /* renamed from: e */
    public static final int e_res_0x7f0b01ce = 2131427790;

    /* renamed from: f */
    public static final int f_res_0x7f0b01cf = 2131427791;

    /* renamed from: g */
    public static final int g_res_0x7f0b01d0 = 2131427792;

    /* renamed from: h */
    public static final int h_res_0x7f0b01d1 = 2131427793;

    /* renamed from: i */
    public static final int i_res_0x7f0b01d2 = 2131427794;

    /* renamed from: j */
    public static final int j_res_0x7f0b01d3 = 2131427795;
}
