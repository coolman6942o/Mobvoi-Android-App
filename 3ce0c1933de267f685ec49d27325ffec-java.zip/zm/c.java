package zm;
/* loaded from: classes2.dex */
public final class c {

    /* renamed from: a */
    public static final int a_res_0x7f0f0003 = 2131689475;
}
