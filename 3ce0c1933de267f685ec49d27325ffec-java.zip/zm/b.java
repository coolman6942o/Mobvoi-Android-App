package zm;
/* loaded from: classes2.dex */
public final class b {

    /* renamed from: a */
    public static final int a_res_0x7f0e007b = 2131624059;

    /* renamed from: b */
    public static final int b_res_0x7f0e007c = 2131624060;
}
