package zm;
/* loaded from: classes2.dex */
public final class d {

    /* renamed from: a */
    public static final int a_res_0x7f1402be = 2132017854;

    /* renamed from: b */
    public static final int b_res_0x7f1402bf = 2132017855;

    /* renamed from: c */
    public static final int c_res_0x7f140c79 = 2132020345;
}
