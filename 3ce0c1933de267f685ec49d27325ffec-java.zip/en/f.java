package en;
/* loaded from: classes2.dex */
public interface f {
    void g(int i10, String str);
}
