package en;
/* loaded from: classes2.dex */
public interface a {
    void a(int i10, int i11, int i12);
}
