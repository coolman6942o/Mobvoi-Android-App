package en;

import java.util.ArrayList;
/* loaded from: classes2.dex */
public class g {

    /* renamed from: a  reason: collision with root package name */
    private ArrayList<m> f26161a;

    /* renamed from: b  reason: collision with root package name */
    private ArrayList<m> f26162b;

    /* renamed from: c  reason: collision with root package name */
    private ArrayList<m> f26163c;

    /* renamed from: d  reason: collision with root package name */
    private ArrayList<m> f26164d;

    public g(ArrayList<m> arrayList) {
        this.f26164d = arrayList;
    }

    public g(ArrayList<m> arrayList, ArrayList<m> arrayList2, ArrayList<m> arrayList3) {
        this.f26161a = arrayList;
        this.f26162b = arrayList2;
        this.f26163c = arrayList3;
    }

    public ArrayList<m> a() {
        return this.f26163c;
    }

    public ArrayList<m> b() {
        return this.f26161a;
    }

    public ArrayList<m> c() {
        return this.f26162b;
    }

    public ArrayList<m> d() {
        return this.f26164d;
    }
}
