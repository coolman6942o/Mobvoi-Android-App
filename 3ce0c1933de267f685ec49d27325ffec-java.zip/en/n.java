package en;

import cn.w;
/* loaded from: classes2.dex */
public interface n {
    void a(w wVar);
}
