package en;
/* loaded from: classes2.dex */
public interface j {
    void e(int i10);
}
