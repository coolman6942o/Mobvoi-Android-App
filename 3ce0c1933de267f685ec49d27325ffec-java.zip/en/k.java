package en;
/* loaded from: classes2.dex */
public interface k {
    void a();
}
