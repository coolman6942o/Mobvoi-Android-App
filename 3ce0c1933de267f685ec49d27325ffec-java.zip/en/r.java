package en;

import android.bluetooth.BluetoothGattCharacteristic;
/* loaded from: classes2.dex */
public interface r {
    void a(BluetoothGattCharacteristic bluetoothGattCharacteristic);

    void b(int i10);

    void c(BluetoothGattCharacteristic bluetoothGattCharacteristic);

    void d(int i10);
}
