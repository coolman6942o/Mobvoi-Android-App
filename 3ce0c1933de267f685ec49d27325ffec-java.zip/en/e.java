package en;

import cn.g;
import cn.j;
import cn.u;
/* loaded from: classes2.dex */
public interface e {
    void a(boolean z10, int i10, int i11, int i12, j jVar);

    void b(boolean z10, String str, int i10, int i11);

    void c(boolean z10, int i10, int i11, int i12);

    void d(int i10);

    void f(boolean z10, int i10, int i11, String str);

    void i(boolean z10, int i10, int i11, int i12, u uVar);

    void j(boolean z10, int i10);

    void k(boolean z10, int i10, g gVar);

    void l(boolean z10, int i10, byte[] bArr);

    void m(boolean z10, int i10, int i11);
}
