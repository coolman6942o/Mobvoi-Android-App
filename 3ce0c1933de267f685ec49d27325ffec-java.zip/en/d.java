package en;

import android.bluetooth.BluetoothDevice;
/* loaded from: classes2.dex */
public interface d {
    void h(BluetoothDevice bluetoothDevice, int i10, byte[] bArr);
}
