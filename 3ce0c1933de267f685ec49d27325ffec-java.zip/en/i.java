package en;
/* loaded from: classes2.dex */
public interface i {
    void a(int i10, int i11, int i12, boolean z10);
}
