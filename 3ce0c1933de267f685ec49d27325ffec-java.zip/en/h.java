package en;
/* loaded from: classes2.dex */
public interface h {
    void a(int i10, int i11);
}
