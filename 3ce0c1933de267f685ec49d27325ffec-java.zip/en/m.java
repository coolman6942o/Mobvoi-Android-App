package en;
/* loaded from: classes2.dex */
public class m {

    /* renamed from: a  reason: collision with root package name */
    private String f26190a;

    /* renamed from: b  reason: collision with root package name */
    private int f26191b;

    /* renamed from: c  reason: collision with root package name */
    private int f26192c;

    /* renamed from: d  reason: collision with root package name */
    private int f26193d;

    /* renamed from: e  reason: collision with root package name */
    private String f26194e;

    public m() {
    }

    public m(String str, int i10, int i11) {
        this.f26190a = str;
        this.f26192c = i10;
        this.f26193d = i11;
    }

    public m(String str, int i10, int i11, int i12) {
        this.f26190a = str;
        this.f26191b = i10;
        this.f26192c = i11;
        this.f26193d = i12;
    }

    public String a() {
        return this.f26190a;
    }

    public int b() {
        return this.f26192c;
    }

    public String c() {
        return this.f26194e;
    }

    public int d() {
        return this.f26193d;
    }

    public int e() {
        return this.f26191b;
    }

    public void f(String str) {
        this.f26190a = str;
    }

    public void g(String str) {
        this.f26194e = str;
    }
}
