package bn;
/* loaded from: classes2.dex */
public class o {

    /* renamed from: a  reason: collision with root package name */
    private float f5335a;

    /* renamed from: b  reason: collision with root package name */
    private float f5336b;

    /* renamed from: c  reason: collision with root package name */
    private float f5337c;

    public o(float f10, float f11, float f12) {
        f(f10);
        d(f11);
        e(f12);
    }

    public float a() {
        return this.f5336b;
    }

    public float b() {
        return this.f5337c;
    }

    public float c() {
        return this.f5335a;
    }

    public void d(float f10) {
        this.f5336b = f10;
    }

    public void e(float f10) {
        this.f5337c = f10;
    }

    public void f(float f10) {
        this.f5335a = f10;
    }
}
