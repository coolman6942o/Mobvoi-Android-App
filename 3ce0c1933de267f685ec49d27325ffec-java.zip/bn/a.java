package bn;

import android.graphics.Bitmap;
/* loaded from: classes2.dex */
public class a {

    /* renamed from: a  reason: collision with root package name */
    int f5273a;

    /* renamed from: b  reason: collision with root package name */
    private Bitmap f5274b;

    /* renamed from: c  reason: collision with root package name */
    int f5275c;

    /* renamed from: d  reason: collision with root package name */
    int f5276d;

    /* renamed from: e  reason: collision with root package name */
    int f5277e;

    /* renamed from: f  reason: collision with root package name */
    int f5278f;

    public a(int i10, Bitmap bitmap, int i11, int i12, int i13, int i14) {
        this.f5273a = 0;
        this.f5275c = 0;
        this.f5276d = 0;
        this.f5277e = 0;
        this.f5278f = 0;
        this.f5273a = i10;
        this.f5274b = bitmap;
        this.f5275c = i11;
        this.f5276d = i12;
        this.f5277e = i13;
        this.f5278f = i14;
    }

    public Bitmap a() {
        return this.f5274b;
    }

    public int b() {
        return this.f5276d;
    }

    public int c() {
        return this.f5275c;
    }

    public int d() {
        return this.f5273a;
    }

    public int e() {
        return this.f5277e;
    }

    public int f() {
        return this.f5278f;
    }
}
