package bn;
/* loaded from: classes2.dex */
public class r {
}
