package bn;
/* loaded from: classes2.dex */
public class k implements Comparable<k> {

    /* renamed from: a  reason: collision with root package name */
    byte[] f5305a = new byte[2];

    /* renamed from: b  reason: collision with root package name */
    byte[] f5306b = new byte[2];

    /* renamed from: c  reason: collision with root package name */
    byte[] f5307c = new byte[4];

    /* renamed from: d  reason: collision with root package name */
    byte[] f5308d = new byte[2];

    /* renamed from: e  reason: collision with root package name */
    byte[] f5309e = new byte[2];

    /* renamed from: f  reason: collision with root package name */
    byte[] f5310f = new byte[2];

    /* renamed from: g  reason: collision with root package name */
    byte[] f5311g = new byte[2];

    /* renamed from: h  reason: collision with root package name */
    byte[] f5312h = new byte[1];

    /* renamed from: i  reason: collision with root package name */
    byte[] f5313i = new byte[7];

    /* renamed from: a */
    public int compareTo(k kVar) {
        return p.y().l(e()) - p.y().l(kVar.e());
    }

    public byte[] b() {
        return this.f5308d;
    }

    public byte[] c() {
        return this.f5307c;
    }

    public byte[] d() {
        return this.f5306b;
    }

    public byte[] e() {
        return this.f5305a;
    }

    public void f(byte[] bArr) {
        this.f5312h = bArr;
    }

    public void g(byte[] bArr) {
        this.f5311g = bArr;
    }

    public void h(byte[] bArr) {
        this.f5308d = bArr;
    }

    public void i(byte[] bArr) {
        this.f5307c = bArr;
    }

    public void j(byte[] bArr) {
        this.f5306b = bArr;
    }

    public void k(byte[] bArr) {
        this.f5313i = bArr;
    }

    public void l(byte[] bArr) {
        this.f5305a = bArr;
    }

    public void m(byte[] bArr) {
        this.f5309e = bArr;
    }

    public void n(byte[] bArr) {
        this.f5310f = bArr;
    }
}
