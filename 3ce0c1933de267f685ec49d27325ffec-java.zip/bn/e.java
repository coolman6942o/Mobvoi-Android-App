package bn;
/* loaded from: classes2.dex */
public class e {

    /* renamed from: a  reason: collision with root package name */
    private int f5292a;

    /* renamed from: b  reason: collision with root package name */
    private int f5293b;

    public e(int i10, int i11) {
        this.f5292a = 0;
        this.f5293b = 0;
        this.f5292a = i10;
        this.f5293b = i11;
    }

    public int a() {
        return this.f5292a;
    }

    public int b() {
        return this.f5293b;
    }
}
