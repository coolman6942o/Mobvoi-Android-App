package bn;
/* loaded from: classes2.dex */
public class s {

    /* renamed from: a  reason: collision with root package name */
    byte[] f5348a = new byte[4];

    /* renamed from: b  reason: collision with root package name */
    byte[] f5349b = new byte[4];

    /* renamed from: c  reason: collision with root package name */
    byte[] f5350c = new byte[4];

    /* renamed from: d  reason: collision with root package name */
    byte[] f5351d = new byte[2];

    /* renamed from: e  reason: collision with root package name */
    byte[] f5352e = new byte[2];

    /* renamed from: f  reason: collision with root package name */
    byte[] f5353f = new byte[1];

    /* renamed from: g  reason: collision with root package name */
    byte[] f5354g = new byte[1];

    /* renamed from: h  reason: collision with root package name */
    byte[] f5355h = new byte[1];

    /* renamed from: i  reason: collision with root package name */
    byte[] f5356i = new byte[5];

    public void a(byte[] bArr) {
        this.f5350c = bArr;
    }

    public void b(byte[] bArr) {
        this.f5349b = bArr;
    }

    public void c(byte[] bArr) {
        this.f5354g = bArr;
    }

    public void d(byte[] bArr) {
        this.f5355h = bArr;
    }

    public void e(byte[] bArr) {
        this.f5352e = bArr;
    }

    public void f(byte[] bArr) {
        this.f5351d = bArr;
    }

    public void g(byte[] bArr) {
        this.f5356i = bArr;
    }

    public void h(byte[] bArr) {
        this.f5353f = bArr;
    }

    public void i(byte[] bArr) {
        this.f5348a = bArr;
    }
}
