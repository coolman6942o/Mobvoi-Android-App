package jo;
/* compiled from: _ComparisonsJvm.kt */
/* loaded from: classes3.dex */
class c extends b {
}
