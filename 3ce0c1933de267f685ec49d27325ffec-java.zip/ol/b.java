package ol;
/* loaded from: classes2.dex */
public final class b {
    public static int a(int i10) {
        switch (i10) {
            case 10128:
                return 0;
            case 10129:
                return 1;
            case 10130:
                return 2;
            case 10131:
                return 3;
            case 10132:
                return 4;
            case 10133:
                return 5;
            case 10134:
                return 6;
            case 10135:
                return 7;
            case 10136:
                return 8;
            default:
                return 254;
        }
    }

    public static int b(int i10, int i11) {
        if (i10 > i11) {
            return 1;
        }
        return i10 == i11 ? 0 : -1;
    }
}
