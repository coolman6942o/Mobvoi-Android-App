package ol;
/* loaded from: classes2.dex */
public final class a {
    public static boolean a(int i10) {
        return i10 == 5 || i10 == 21 || i10 == 4 || i10 == 20 || i10 == 2 || i10 == 18 || i10 == 7 || i10 == 23 || i10 == 6 || i10 == 22;
    }

    public static boolean b(int i10) {
        return i10 == 8 || i10 == 24 || i10 == 9 || i10 == 25 || i10 == 10 || i10 == 26;
    }
}
