package rx;
/* compiled from: Producer.java */
/* loaded from: classes3.dex */
public interface e {
    void request(long j10);
}
