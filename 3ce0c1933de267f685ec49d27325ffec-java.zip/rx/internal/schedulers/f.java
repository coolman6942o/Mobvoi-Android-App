package rx.internal.schedulers;
/* compiled from: SchedulerLifecycle.java */
/* loaded from: classes3.dex */
public interface f {
    void shutdown();
}
