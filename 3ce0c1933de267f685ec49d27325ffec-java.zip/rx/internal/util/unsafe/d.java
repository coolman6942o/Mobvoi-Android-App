package rx.internal.util.unsafe;
/* compiled from: BaseLinkedQueue.java */
/* loaded from: classes3.dex */
abstract class d<E> extends e<E> {
}
