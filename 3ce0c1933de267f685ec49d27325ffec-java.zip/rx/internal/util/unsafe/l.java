package rx.internal.util.unsafe;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: SpmcArrayQueue.java */
/* loaded from: classes3.dex */
public abstract class l<E> extends f<E> {
    public l(int i10) {
        super(i10);
    }
}
