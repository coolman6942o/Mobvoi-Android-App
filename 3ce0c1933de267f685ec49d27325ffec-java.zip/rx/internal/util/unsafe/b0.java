package rx.internal.util.unsafe;
/* compiled from: SpscUnboundedArrayQueue.java */
/* loaded from: classes3.dex */
abstract class b0<E> extends a0<E> {
    protected long consumerIndex;
}
