package rx.internal.util.unsafe;
/* compiled from: SpscUnboundedArrayQueue.java */
/* loaded from: classes3.dex */
abstract class c0<E> extends d0<E> {
}
