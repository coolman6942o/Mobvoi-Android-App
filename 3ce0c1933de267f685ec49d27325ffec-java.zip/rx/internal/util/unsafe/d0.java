package rx.internal.util.unsafe;
/* compiled from: SpscUnboundedArrayQueue.java */
/* loaded from: classes3.dex */
abstract class d0<E> extends e0<E> {

    /* renamed from: a  reason: collision with root package name */
    protected int f34159a;

    /* renamed from: b  reason: collision with root package name */
    protected long f34160b;

    /* renamed from: c  reason: collision with root package name */
    protected long f34161c;

    /* renamed from: d  reason: collision with root package name */
    protected E[] f34162d;
}
