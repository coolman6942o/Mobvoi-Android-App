package rx.internal.util.unsafe;

import java.util.AbstractQueue;
/* compiled from: SpscUnboundedArrayQueue.java */
/* loaded from: classes3.dex */
abstract class e0<E> extends AbstractQueue<E> {
    protected long producerIndex;
}
