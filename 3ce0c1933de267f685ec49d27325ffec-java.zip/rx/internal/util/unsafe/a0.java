package rx.internal.util.unsafe;
/* compiled from: SpscUnboundedArrayQueue.java */
/* loaded from: classes3.dex */
abstract class a0<E> extends c0<E> {

    /* renamed from: e  reason: collision with root package name */
    protected long f34156e;

    /* renamed from: f  reason: collision with root package name */
    protected E[] f34157f;
}
