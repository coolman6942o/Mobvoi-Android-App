package rx.internal.util.unsafe;
/* compiled from: SpmcArrayQueue.java */
/* loaded from: classes3.dex */
abstract class m<E> extends p<E> {
    public m(int i10) {
        super(i10);
    }
}
