package rx.internal.util.unsafe;
/* compiled from: SpscArrayQueue.java */
/* loaded from: classes3.dex */
abstract class t<E> extends v<E> {

    /* renamed from: h  reason: collision with root package name */
    protected static final long f34175h = f0.a(t.class, "consumerIndex");
    protected long consumerIndex;

    public t(int i10) {
        super(i10);
    }
}
