package rx.internal.util.unsafe;
/* compiled from: SpmcArrayQueue.java */
/* loaded from: classes3.dex */
abstract class n<E> extends q<E> {
    public n(int i10) {
        super(i10);
    }
}
