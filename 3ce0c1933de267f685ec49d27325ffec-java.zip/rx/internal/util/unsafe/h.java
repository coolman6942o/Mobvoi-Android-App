package rx.internal.util.unsafe;
/* compiled from: MessagePassingQueue.java */
/* loaded from: classes3.dex */
public interface h<M> {
    M poll();
}
