package rx.internal.util.unsafe;
/* compiled from: SpscArrayQueue.java */
/* loaded from: classes3.dex */
abstract class x<E> extends u<E> {

    /* renamed from: g  reason: collision with root package name */
    protected static final long f34176g = f0.a(x.class, "producerIndex");
    protected long producerIndex;

    public x(int i10) {
        super(i10);
    }
}
