package rx.internal.util.unsafe;

import java.util.AbstractQueue;
/* compiled from: ConcurrentCircularArrayQueue.java */
/* loaded from: classes3.dex */
abstract class g<E> extends AbstractQueue<E> implements h<E> {
}
