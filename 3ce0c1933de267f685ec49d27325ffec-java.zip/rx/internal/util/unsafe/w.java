package rx.internal.util.unsafe;
/* compiled from: SpscArrayQueue.java */
/* loaded from: classes3.dex */
abstract class w<E> extends t<E> {
    public w(int i10) {
        super(i10);
    }
}
