package rx.internal.util.unsafe;
/* compiled from: SpscArrayQueue.java */
/* loaded from: classes3.dex */
abstract class v<E> extends x<E> {
    public v(int i10) {
        super(i10);
    }
}
