package rx.internal.util.unsafe;

import java.util.AbstractQueue;
/* compiled from: BaseLinkedQueue.java */
/* loaded from: classes3.dex */
abstract class c<E> extends AbstractQueue<E> {
}
