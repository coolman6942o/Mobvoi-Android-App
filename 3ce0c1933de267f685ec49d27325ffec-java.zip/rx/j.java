package rx;
/* compiled from: Subscription.java */
/* loaded from: classes3.dex */
public interface j {
    boolean isUnsubscribed();

    void unsubscribe();
}
