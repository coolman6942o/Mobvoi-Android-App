package rx;
/* compiled from: CompletableSubscriber.java */
/* loaded from: classes3.dex */
public interface b {
    void a(j jVar);

    void onCompleted();

    void onError(Throwable th2);
}
