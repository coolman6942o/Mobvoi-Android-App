package f2;

import cn.com.fmsh.communication.message.exception.FMCommunicationMessageException;
/* loaded from: classes.dex */
public interface a {
    byte[] a() throws FMCommunicationMessageException;

    c b(int i10) throws FMCommunicationMessageException;

    int c(c cVar) throws FMCommunicationMessageException;
}
