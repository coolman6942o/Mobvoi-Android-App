package f2;

import cn.com.fmsh.communication.message.exception.FMCommunicationMessageException;
/* loaded from: classes.dex */
public interface c {
    byte[] a() throws FMCommunicationMessageException;

    boolean b();

    int c(int i10) throws FMCommunicationMessageException;

    int d() throws FMCommunicationMessageException;

    int e(byte[] bArr) throws FMCommunicationMessageException;

    int f(String str) throws FMCommunicationMessageException;

    String g() throws FMCommunicationMessageException;

    byte getId();

    byte[] h() throws FMCommunicationMessageException;

    int i(c cVar) throws FMCommunicationMessageException;

    c[] j() throws FMCommunicationMessageException;

    int k() throws FMCommunicationMessageException;

    c l(int i10) throws FMCommunicationMessageException;
}
