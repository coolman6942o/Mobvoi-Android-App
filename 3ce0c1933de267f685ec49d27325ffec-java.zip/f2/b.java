package f2;

import cn.com.fmsh.communication.message.exception.FMCommunicationMessageException;
import java.io.InputStream;
/* loaded from: classes.dex */
public interface b {
    int a(InputStream inputStream) throws FMCommunicationMessageException;

    a b(int i10, byte[] bArr) throws FMCommunicationMessageException;

    c c(byte b10);

    a d(byte[] bArr) throws FMCommunicationMessageException;

    a e(int i10);
}
