package o2;

import java.util.List;
import q2.b;
/* loaded from: classes.dex */
public interface a {
    List<b> a();
}
