package ra;

import ua.a;
import ua.b;
/* compiled from: Injection.java */
/* loaded from: classes2.dex */
public class h {
    public static a a() {
        return b.c();
    }

    public static b b() {
        return com.mobvoi.assistant.account.data.a.v();
    }
}
