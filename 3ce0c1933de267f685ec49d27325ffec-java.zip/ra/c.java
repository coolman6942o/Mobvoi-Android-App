package ra;
/* compiled from: AccountCallback.java */
/* loaded from: classes2.dex */
public interface c {
    void a();

    void b(String str);
}
