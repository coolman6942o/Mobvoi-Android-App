package ra;

import sa.a;
/* compiled from: AccountInfoChangeCallback.java */
/* loaded from: classes2.dex */
public interface d {
    void a(a aVar);
}
