package ra;

import okhttp3.a0;
import okhttp3.x;
import rx.c;
import sa.a;
import sa.d;
import sa.e;
import sa.f;
import sa.g;
import sa.h;
import sa.i;
import sa.j;
import sa.k;
import sa.l;
import sa.m;
/* compiled from: AccountApiHelper.java */
/* loaded from: classes2.dex */
public interface b {
    c<sa.c> a(k kVar);

    c<g> b(e eVar);

    c<sa.c> c(String str);

    c<sa.c> d(i iVar);

    c<sa.c> e(a aVar);

    c<sa.c> f(String str, boolean z10);

    c<g> g(l lVar);

    c<g> h(f fVar);

    c<sa.c> i(String str, String str2, String str3, String str4, String str5);

    c<g> j(String str, String str2, String str3);

    c<d> k(a0 a0Var, x.c cVar);

    c<sa.c> l(m mVar);

    c<sa.c> m(String str, h hVar);

    c<sa.c> n(j jVar);
}
