package bf;

import android.content.Context;
import hf.a;
/* compiled from: WeeklyMotionClient.java */
/* loaded from: classes2.dex */
public class f implements a {
    public f(Context context) {
        new e(context);
    }
}
