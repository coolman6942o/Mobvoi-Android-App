package bf;
/* compiled from: SportServer.java */
/* loaded from: classes2.dex */
public interface c {
    <T> T a(Class<T> cls);

    String b();
}
