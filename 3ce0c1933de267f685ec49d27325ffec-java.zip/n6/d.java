package n6;

import android.os.IInterface;
import android.os.RemoteException;
/* loaded from: classes.dex */
public interface d extends IInterface {
    boolean f0(boolean z10) throws RemoteException;

    String getId() throws RemoteException;
}
