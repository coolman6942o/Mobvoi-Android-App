package n6;

import android.os.Binder;
import android.os.IInterface;
/* loaded from: classes.dex */
public class b extends Binder implements IInterface {
}
