package v4;

import q4.b;
import t4.c;
/* compiled from: MemoryCache.java */
/* loaded from: classes.dex */
public interface h {

    /* compiled from: MemoryCache.java */
    /* loaded from: classes.dex */
    public interface a {
        void a(c<?> cVar);
    }

    void a(int i10);

    void b();

    c<?> c(b bVar);

    void d(a aVar);

    c<?> e(b bVar, c<?> cVar);
}
