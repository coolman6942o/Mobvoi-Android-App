package v4;

import java.io.File;
import v4.a;
/* compiled from: DiskCacheAdapter.java */
/* loaded from: classes.dex */
public class b implements a {
    @Override // v4.a
    public void a(q4.b bVar, a.b bVar2) {
    }

    @Override // v4.a
    public File b(q4.b bVar) {
        return null;
    }
}
