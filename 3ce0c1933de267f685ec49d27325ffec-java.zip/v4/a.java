package v4;

import java.io.File;
/* compiled from: DiskCache.java */
/* loaded from: classes.dex */
public interface a {

    /* compiled from: DiskCache.java */
    /* renamed from: v4.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface AbstractC0513a {
        a build();
    }

    /* compiled from: DiskCache.java */
    /* loaded from: classes.dex */
    public interface b {
        boolean a(File file);
    }

    void a(q4.b bVar, b bVar2);

    File b(q4.b bVar);
}
