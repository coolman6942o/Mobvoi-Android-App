package r2;

import cn.com.fmsh.tsm.business.enums.EnumIssueProcess;
/* loaded from: classes.dex */
public interface e {
    void a(EnumIssueProcess enumIssueProcess);
}
