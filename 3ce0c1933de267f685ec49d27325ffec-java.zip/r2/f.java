package r2;
/* loaded from: classes.dex */
public interface f {
}
