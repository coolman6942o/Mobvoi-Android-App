package r2;

import cn.com.fmsh.script.ApduHandler;
/* loaded from: classes.dex */
public interface a {
    void a(ApduHandler apduHandler);

    c b();

    void c(byte[] bArr);

    void d(f fVar);

    d e();
}
