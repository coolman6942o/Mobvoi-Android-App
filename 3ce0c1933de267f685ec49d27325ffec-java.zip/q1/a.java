package q1;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f32908a = {16842948};

    /* renamed from: b  reason: collision with root package name */
    public static final int f32909b = 0;
}
