package yc;

import com.cardiex.arty.lite.models.coach.Action;
import com.cardiex.arty.lite.models.coach.Advice;
import java.util.List;
import zc.a;
/* compiled from: ArtyCardData.kt */
/* loaded from: classes2.dex */
public final class c {

    /* renamed from: a  reason: collision with root package name */
    private Action f36944a;

    /* renamed from: b  reason: collision with root package name */
    private Advice f36945b;

    /* renamed from: c  reason: collision with root package name */
    private List<a> f36946c;

    public final Advice a() {
        return this.f36945b;
    }

    public final List<a> b() {
        return this.f36946c;
    }

    public final Action c() {
        return this.f36944a;
    }

    public final void d(Advice advice) {
        this.f36945b = advice;
    }

    public final void e(List<a> list) {
        this.f36946c = list;
    }

    public final void f(Action action) {
        this.f36944a = action;
    }
}
