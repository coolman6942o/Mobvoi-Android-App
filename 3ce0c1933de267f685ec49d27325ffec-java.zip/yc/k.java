package yc;

import zc.a;
/* compiled from: ArtyCardViewInterface.kt */
/* loaded from: classes2.dex */
public interface k {
    void c(a aVar);
}
