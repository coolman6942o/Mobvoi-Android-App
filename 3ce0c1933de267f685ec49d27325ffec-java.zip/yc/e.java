package yc;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.c;
/* loaded from: classes3.dex */
public final /* synthetic */ class e implements c.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ e f36976a = new e();

    private /* synthetic */ e() {
    }

    @Override // com.google.android.material.tabs.c.b
    public final void a(TabLayout.g gVar, int i10) {
        f.F(gVar, i10);
    }
}
