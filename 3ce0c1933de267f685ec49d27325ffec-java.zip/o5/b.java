package o5;
/* compiled from: GlideTrace.java */
/* loaded from: classes.dex */
public final class b {
    public static void a(String str) {
    }

    public static void b(String str, Object obj) {
    }

    public static void c(String str, Object obj, Object obj2, Object obj3) {
    }

    public static void d() {
    }
}
