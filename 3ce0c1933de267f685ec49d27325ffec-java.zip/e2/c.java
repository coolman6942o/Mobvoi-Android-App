package e2;
/* loaded from: classes.dex */
public class c {

    /* renamed from: a  reason: collision with root package name */
    private /* synthetic */ byte[] f25721a;

    /* renamed from: b  reason: collision with root package name */
    private /* synthetic */ byte[] f25722b;

    /* renamed from: c  reason: collision with root package name */
    private /* synthetic */ byte[] f25723c;

    /* renamed from: d  reason: collision with root package name */
    private /* synthetic */ byte f25724d;

    /* renamed from: e  reason: collision with root package name */
    private /* synthetic */ byte[] f25725e;

    /* renamed from: f  reason: collision with root package name */
    private /* synthetic */ byte[] f25726f;

    /* renamed from: g  reason: collision with root package name */
    private /* synthetic */ byte[] f25727g;

    public byte[] a() {
        return this.f25723c;
    }

    public byte[] b() {
        return this.f25726f;
    }

    public byte c() {
        return this.f25724d;
    }

    public byte[] d() {
        return this.f25725e;
    }

    public byte[] e() {
        return this.f25722b;
    }

    public byte[] f() {
        return this.f25727g;
    }

    public byte[] g() {
        return this.f25721a;
    }

    public void h(byte[] bArr) {
        this.f25723c = bArr;
    }

    public void i(byte[] bArr) {
        this.f25726f = bArr;
    }

    public void j(byte b10) {
        this.f25724d = b10;
    }

    public void k(byte[] bArr) {
        this.f25725e = bArr;
    }

    public void l(byte[] bArr) {
        this.f25722b = bArr;
    }

    public void m(byte[] bArr) {
        this.f25727g = bArr;
    }

    public void n(byte[] bArr) {
        this.f25721a = bArr;
    }
}
