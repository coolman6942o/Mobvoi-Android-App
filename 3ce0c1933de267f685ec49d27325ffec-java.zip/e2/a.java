package e2;

import x2.d;
import x2.h;
/* loaded from: classes.dex */
public class a {

    /* renamed from: a  reason: collision with root package name */
    private /* synthetic */ byte[] f25719a;

    public byte[] a() {
        byte[] bArr = new byte[7];
        if (this.f25719a == null) {
            this.f25719a = d.f(h.c(x2.a.b("9e!-]A, H\u00145yc?", 208, 92)));
        }
        for (int i10 = 0; i10 < 7; i10++) {
            bArr[i10 + 0] = this.f25719a[i10];
        }
        return bArr;
    }
}
