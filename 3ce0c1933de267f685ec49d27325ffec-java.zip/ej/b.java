package ej;
/* loaded from: classes2.dex */
public final /* synthetic */ class b implements yp.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ b f26097a = new b();

    private /* synthetic */ b() {
    }

    @Override // yp.b
    public final void call(Object obj) {
        d.l((Throwable) obj);
    }
}
