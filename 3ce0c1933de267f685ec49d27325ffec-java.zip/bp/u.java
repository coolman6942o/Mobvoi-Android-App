package bp;
/* loaded from: classes3.dex */
public final class u {

    /* renamed from: a */
    public static final int a_res_0x7f1403a2 = 2132018082;

    /* renamed from: b */
    public static final int b_res_0x7f1403a5 = 2132018085;

    /* renamed from: c */
    public static final int c_res_0x7f1403a6 = 2132018086;

    /* renamed from: d */
    public static final int d_res_0x7f1403a8 = 2132018088;

    /* renamed from: e */
    public static final int e_res_0x7f1403a9 = 2132018089;

    /* renamed from: f */
    public static final int f_res_0x7f1403aa = 2132018090;

    /* renamed from: g */
    public static final int g_res_0x7f1403ab = 2132018091;

    /* renamed from: h */
    public static final int h_res_0x7f1403ac = 2132018092;

    /* renamed from: i */
    public static final int i_res_0x7f1403ad = 2132018093;

    /* renamed from: j */
    public static final int j_res_0x7f1403ae = 2132018094;

    /* renamed from: k */
    public static final int k_res_0x7f1403af = 2132018095;

    /* renamed from: l */
    public static final int l_res_0x7f1403b0 = 2132018096;

    /* renamed from: m */
    public static final int m_res_0x7f1403b1 = 2132018097;

    /* renamed from: n */
    public static final int n_res_0x7f1403b3 = 2132018099;

    /* renamed from: o */
    public static final int o_res_0x7f1403b4 = 2132018100;

    /* renamed from: p */
    public static final int p_res_0x7f1403b5 = 2132018101;

    /* renamed from: q */
    public static final int q_res_0x7f1403b6 = 2132018102;

    /* renamed from: r */
    public static final int r_res_0x7f1403b7 = 2132018103;

    /* renamed from: s */
    public static final int s_res_0x7f1403b8 = 2132018104;

    /* renamed from: t */
    public static final int t_res_0x7f1403b9 = 2132018105;

    /* renamed from: u */
    public static final int u_res_0x7f1403ba = 2132018106;

    /* renamed from: v */
    public static final int v_res_0x7f1403bb = 2132018107;

    /* renamed from: w */
    public static final int w_res_0x7f1403bc = 2132018108;
}
