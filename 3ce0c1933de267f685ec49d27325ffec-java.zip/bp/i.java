package bp;
/* compiled from: DfuController.java */
/* loaded from: classes3.dex */
public interface i {
    void a();

    void b();

    void d();
}
