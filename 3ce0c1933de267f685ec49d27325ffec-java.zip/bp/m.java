package bp;

import android.content.Context;
import b1.a;
/* compiled from: DfuServiceController.java */
/* loaded from: classes3.dex */
public class m implements i {
    /* JADX INFO: Access modifiers changed from: package-private */
    public m(Context context) {
        a.b(context);
    }
}
