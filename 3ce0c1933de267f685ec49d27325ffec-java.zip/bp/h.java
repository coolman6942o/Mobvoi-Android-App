package bp;

import android.bluetooth.BluetoothGattCallback;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: DfuCallback.java */
/* loaded from: classes3.dex */
public interface h extends i {

    /* compiled from: DfuCallback.java */
    /* loaded from: classes3.dex */
    public static class a extends BluetoothGattCallback {
        public void a() {
            throw null;
        }
    }

    void c(int i10);

    a e();
}
