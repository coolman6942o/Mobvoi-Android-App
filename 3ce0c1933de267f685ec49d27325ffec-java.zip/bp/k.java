package bp;
/* compiled from: DfuProgressListener.java */
/* loaded from: classes3.dex */
public interface k {
    void a(String str);

    void b(String str);

    void c(String str);

    void d(String str, int i10, int i11, String str2);

    void e(String str, int i10, float f10, float f11, int i11, int i12);

    void f(String str);

    void g(String str);

    void h(String str);

    void i(String str);

    void j(String str);

    void k(String str);

    void l(String str);
}
