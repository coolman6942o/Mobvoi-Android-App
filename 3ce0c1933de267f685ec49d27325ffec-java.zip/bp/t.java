package bp;
/* loaded from: classes3.dex */
public final class t {

    /* renamed from: a  reason: collision with root package name */
    public static final int f5503a = 2131231203;
}
