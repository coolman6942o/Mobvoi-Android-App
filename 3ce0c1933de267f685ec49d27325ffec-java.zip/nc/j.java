package nc;

import com.google.common.base.v;
import ho.a;
import retrofit2.Retrofit;
import un.b;
/* compiled from: MobvoiPushModule_ProvideMobvoiDevPushApiFactory.java */
/* loaded from: classes2.dex */
public final class j implements a {
    public static v<a> a(Retrofit retrofit) {
        return (v) b.c(i.f31129a.c(retrofit));
    }
}
