package nc;

import com.mobvoi.be.pushunicorn.PushUnicornProto;
/* loaded from: classes3.dex */
public final /* synthetic */ class b implements yp.b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ b f31122a = new b();

    private /* synthetic */ b() {
    }

    @Override // yp.b
    public final void call(Object obj) {
        d.g((PushUnicornProto.UserPushResponse) obj);
    }
}
