package nc;

import ho.a;
import okhttp3.y;
import un.b;
/* compiled from: MobvoiPushModule_ProvideOkHttpClientFactory.java */
/* loaded from: classes2.dex */
public final class l implements a {
    public static y a() {
        return (y) b.c(i.f31129a.g());
    }
}
