package nc;

import com.google.common.base.v;
/* compiled from: MobvoiPushApiHelper_MembersInjector.java */
/* loaded from: classes2.dex */
public final class f {
    public static void a(d dVar, v<a> vVar) {
        dVar.f31126c = vVar;
    }

    public static void b(d dVar, v<a> vVar) {
        dVar.f31125b = vVar;
    }
}
