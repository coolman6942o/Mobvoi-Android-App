package nc;

import yp.b;
/* loaded from: classes3.dex */
public final /* synthetic */ class c implements b {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ c f31123a = new c();

    private /* synthetic */ c() {
    }

    @Override // yp.b
    public final void call(Object obj) {
        d.h((Throwable) obj);
    }
}
