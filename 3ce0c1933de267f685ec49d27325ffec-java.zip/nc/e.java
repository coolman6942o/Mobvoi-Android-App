package nc;

import android.content.Context;
import ho.a;
/* compiled from: MobvoiPushApiHelper_Factory.java */
/* loaded from: classes2.dex */
public final class e implements a {
    public static d a(Context context) {
        return new d(context);
    }
}
