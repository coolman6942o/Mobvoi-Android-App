package nc;

import ho.a;
import okhttp3.y;
import retrofit2.Retrofit;
import un.b;
/* compiled from: MobvoiPushModule_ProvideRetrofitDevFactory.java */
/* loaded from: classes2.dex */
public final class m implements a {
    public static Retrofit a(y yVar) {
        return (Retrofit) b.c(i.f31129a.i(yVar));
    }
}
