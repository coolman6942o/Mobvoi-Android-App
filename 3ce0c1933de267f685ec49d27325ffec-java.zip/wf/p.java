package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: SupportRRIResponse.java */
/* loaded from: classes2.dex */
public class p extends o {
    public a data;

    /* compiled from: SupportRRIResponse.java */
    /* loaded from: classes2.dex */
    public static class a implements JsonBean {
        public boolean rriDisabled;
    }
}
