package wf;

import java.util.List;
/* compiled from: DataSessionResponse.java */
/* loaded from: classes2.dex */
public class f extends o {
    public String data_source_name;
    public List<String> fail_session_ids;
    public List<String> repeat_session_ids;
    public List<String> success_session_ids;
}
