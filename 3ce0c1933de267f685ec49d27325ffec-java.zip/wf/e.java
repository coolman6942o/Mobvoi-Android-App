package wf;

import com.mobvoi.android.common.json.JsonBean;
import java.util.List;
/* compiled from: DataSessionRequest.java */
/* loaded from: classes2.dex */
public class e implements JsonBean {
    public List<d> data_sessions;
}
