package wf;

import java.util.List;
/* compiled from: DataSetsResponse.java */
/* loaded from: classes2.dex */
public class j extends o {
    public List<a> data_set_responses;

    /* compiled from: DataSetsResponse.java */
    /* loaded from: classes2.dex */
    public static class a extends o {
        public String data_source_name;
        public List<Object> wrong_points;
    }
}
