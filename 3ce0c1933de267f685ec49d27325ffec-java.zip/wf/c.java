package wf;
/* compiled from: CreateDataSourceResponse.java */
/* loaded from: classes2.dex */
public class c extends o {
    public String data_source_name;
}
