package wf;

import java.util.List;
/* compiled from: DataSessionSearchResponse.java */
/* loaded from: classes2.dex */
public class g extends o {
    public List<d> data_sessions;
    public String data_source_name;
}
