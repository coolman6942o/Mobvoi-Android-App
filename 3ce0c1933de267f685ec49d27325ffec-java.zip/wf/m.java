package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: Device.java */
/* loaded from: classes2.dex */
public class m implements JsonBean {

    /* renamed from: id  reason: collision with root package name */
    public String f36231id;
    public String model;
    public String type;
    public String version;

    public String toString() {
        return "Device[type=" + this.type + ", id=" + this.f36231id + ", model=" + this.model + "]";
    }
}
