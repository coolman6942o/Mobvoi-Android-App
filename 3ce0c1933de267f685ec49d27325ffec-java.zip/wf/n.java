package wf;

import java.util.List;
/* compiled from: GetDataSourceResponse.java */
/* loaded from: classes2.dex */
public class n extends o {
    public List<l> data_sources;
}
