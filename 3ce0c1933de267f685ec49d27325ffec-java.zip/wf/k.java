package wf;

import java.util.List;
/* compiled from: DataSetsSearchResponse.java */
/* loaded from: classes2.dex */
public class k extends o {
    public List<h> data_sets;
}
