package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: CreateDataSourceRequest.java */
/* loaded from: classes2.dex */
public class b implements JsonBean {
    public m device = new m();
    public a application = new a();
}
