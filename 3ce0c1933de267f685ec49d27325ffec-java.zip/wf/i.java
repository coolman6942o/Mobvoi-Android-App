package wf;

import com.mobvoi.android.common.json.JsonBean;
import java.util.List;
/* compiled from: DataSetsRequest.java */
/* loaded from: classes2.dex */
public class i implements JsonBean {
    public List<h> data_sets;
}
