package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: UserSettingRequest.java */
/* loaded from: classes2.dex */
public class q implements JsonBean {
    public String type;
    public String value;

    public q(String str, String str2) {
        this.type = str;
        this.value = str2;
    }
}
