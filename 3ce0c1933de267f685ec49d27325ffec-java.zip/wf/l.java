package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: DataSource.java */
/* loaded from: classes2.dex */
public class l implements JsonBean {
    public int data_source_id;
    public String data_source_name;
    public m device = new m();
    public a application = new a();
}
