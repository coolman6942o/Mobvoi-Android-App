package wf;

import com.mobvoi.android.common.json.JsonBean;
/* compiled from: Application.java */
/* loaded from: classes2.dex */
public class a implements JsonBean {
    public String package_name;
    public String version;
}
