package hi;

import com.mobvoi.mcuwatch.pair.service.DataSyncService;
import fi.a;
import yp.g;
/* loaded from: classes2.dex */
public final /* synthetic */ class d implements g {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ d f27866a = new d();

    private /* synthetic */ d() {
    }

    @Override // yp.g
    public final Object call(Object obj) {
        a i10;
        i10 = DataSyncService.i(obj);
        return i10;
    }
}
