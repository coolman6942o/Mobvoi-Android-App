package hi;

import com.mobvoi.mcuwatch.pair.service.DataSyncService;
import yp.g;
/* loaded from: classes2.dex */
public final /* synthetic */ class c implements g {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ c f27865a = new c();

    private /* synthetic */ c() {
    }

    @Override // yp.g
    public final Object call(Object obj) {
        Boolean h10;
        h10 = DataSyncService.h(obj);
        return h10;
    }
}
