package i9;
/* compiled from: IFileDownloadServiceProxy.java */
/* loaded from: classes2.dex */
public interface e {
}
