package i9;

import com.liulishuo.filedownloader.services.c;
import r9.d;
/* compiled from: FileDownloadServiceProxy.java */
/* loaded from: classes2.dex */
public class b implements e {

    /* renamed from: a  reason: collision with root package name */
    private final e f28207a;

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: FileDownloadServiceProxy.java */
    /* renamed from: i9.b$b  reason: collision with other inner class name */
    /* loaded from: classes2.dex */
    public static final class C0312b {

        /* renamed from: a  reason: collision with root package name */
        private static final b f28208a = new b();
    }

    public static c.a a() {
        if (b().f28207a instanceof c) {
            return (c.a) b().f28207a;
        }
        return null;
    }

    public static b b() {
        return C0312b.f28208a;
    }

    private b() {
        this.f28207a = d.a().f33473d ? new c() : new d();
    }
}
