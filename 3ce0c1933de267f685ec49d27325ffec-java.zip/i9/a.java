package i9;
/* compiled from: FileDownloadEventPool.java */
/* loaded from: classes2.dex */
public class a extends l9.a {

    /* compiled from: FileDownloadEventPool.java */
    /* loaded from: classes2.dex */
    private static class b {

        /* renamed from: a  reason: collision with root package name */
        private static final a f28206a = new a();
    }

    public static a d() {
        return b.f28206a;
    }

    private a() {
    }
}
