package i9;

import com.liulishuo.filedownloader.model.FileDownloadModel;
/* compiled from: IThreadPoolMonitor.java */
/* loaded from: classes2.dex */
public interface f {
    boolean a(FileDownloadModel fileDownloadModel);

    int b(String str, int i10);
}
