package s4;

import android.database.Cursor;
import android.net.Uri;
/* compiled from: ThumbnailQuery.java */
/* loaded from: classes.dex */
interface d {
    Cursor a(Uri uri);
}
