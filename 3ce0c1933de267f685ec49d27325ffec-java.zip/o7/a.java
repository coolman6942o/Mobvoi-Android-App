package o7;
/* compiled from: ExpandableWidget.java */
/* loaded from: classes.dex */
public interface a {
    boolean isExpanded();
}
