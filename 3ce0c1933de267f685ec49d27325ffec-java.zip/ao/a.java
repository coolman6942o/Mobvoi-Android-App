package ao;

import xn.b;
/* compiled from: DisposableContainer.java */
/* loaded from: classes.dex */
public interface a {
    boolean a(b bVar);

    boolean b(b bVar);

    boolean c(b bVar);
}
