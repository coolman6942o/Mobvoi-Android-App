package ao;

import xn.b;
/* compiled from: ResettableConnectable.java */
/* loaded from: classes.dex */
public interface c {
    void a(b bVar);
}
