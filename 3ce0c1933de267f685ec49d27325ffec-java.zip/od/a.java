package od;
/* loaded from: classes2.dex */
public final class a {

    /* renamed from: a */
    public static final int a_res_0x7f0800c2 = 2131230914;

    /* renamed from: b  reason: collision with root package name */
    public static final int f31565b = 2131230982;

    /* renamed from: c  reason: collision with root package name */
    public static final int f31566c = 2131231529;

    /* renamed from: d  reason: collision with root package name */
    public static final int f31567d = 2131231537;

    /* renamed from: e  reason: collision with root package name */
    public static final int f31568e = 2131231549;

    /* renamed from: f  reason: collision with root package name */
    public static final int f31569f = 2131231551;

    /* renamed from: g  reason: collision with root package name */
    public static final int f31570g = 2131231552;

    /* renamed from: h  reason: collision with root package name */
    public static final int f31571h = 2131231553;

    /* renamed from: i  reason: collision with root package name */
    public static final int f31572i = 2131231554;

    /* renamed from: j  reason: collision with root package name */
    public static final int f31573j = 2131231555;

    /* renamed from: k  reason: collision with root package name */
    public static final int f31574k = 2131231556;

    /* renamed from: l  reason: collision with root package name */
    public static final int f31575l = 2131231557;

    /* renamed from: m  reason: collision with root package name */
    public static final int f31576m = 2131231563;

    /* renamed from: n  reason: collision with root package name */
    public static final int f31577n = 2131231587;

    /* renamed from: o  reason: collision with root package name */
    public static final int f31578o = 2131231588;

    /* renamed from: p  reason: collision with root package name */
    public static final int f31579p = 2131231770;

    /* renamed from: q  reason: collision with root package name */
    public static final int f31580q = 2131231781;

    /* renamed from: r  reason: collision with root package name */
    public static final int f31581r = 2131231782;

    /* renamed from: s  reason: collision with root package name */
    public static final int f31582s = 2131231791;

    /* renamed from: t  reason: collision with root package name */
    public static final int f31583t = 2131231793;

    /* renamed from: u  reason: collision with root package name */
    public static final int f31584u = 2131231796;
}
