package od;
/* loaded from: classes2.dex */
public final class d {
    public static final int A = 2132021824;
    public static final int B = 2132021825;
    public static final int C = 2132021841;
    public static final int D = 2132021842;

    /* renamed from: a  reason: collision with root package name */
    public static final int f31587a = 2132017766;

    /* renamed from: b  reason: collision with root package name */
    public static final int f31588b = 2132017769;

    /* renamed from: c  reason: collision with root package name */
    public static final int f31589c = 2132017772;

    /* renamed from: d  reason: collision with root package name */
    public static final int f31590d = 2132017786;

    /* renamed from: e */
    public static final int e_res_0x7f1402a7 = 2132017831;

    /* renamed from: f */
    public static final int f_res_0x7f1402aa = 2132017834;

    /* renamed from: g */
    public static final int g_res_0x7f1402ab = 2132017835;

    /* renamed from: h */
    public static final int h_res_0x7f1402ac = 2132017836;

    /* renamed from: i  reason: collision with root package name */
    public static final int f31591i = 2132018251;

    /* renamed from: j  reason: collision with root package name */
    public static final int f31592j = 2132019564;

    /* renamed from: k */
    public static final int k_res_0x7f140b01 = 2132019969;

    /* renamed from: l */
    public static final int l_res_0x7f140c35 = 2132020277;

    /* renamed from: m */
    public static final int m_res_0x7f140c36 = 2132020278;

    /* renamed from: n */
    public static final int n_res_0x7f140c37 = 2132020279;

    /* renamed from: o */
    public static final int o_res_0x7f140c38 = 2132020280;

    /* renamed from: p */
    public static final int p_res_0x7f140c39 = 2132020281;

    /* renamed from: q */
    public static final int q_res_0x7f140c3a = 2132020282;

    /* renamed from: r */
    public static final int r_res_0x7f140c3b = 2132020283;

    /* renamed from: s */
    public static final int s_res_0x7f140c3c = 2132020284;

    /* renamed from: t */
    public static final int t_res_0x7f140d64 = 2132020580;

    /* renamed from: u */
    public static final int u_res_0x7f140fcc = 2132021196;

    /* renamed from: v */
    public static final int v_res_0x7f14115f = 2132021599;

    /* renamed from: w  reason: collision with root package name */
    public static final int f31593w = 2132021602;

    /* renamed from: x  reason: collision with root package name */
    public static final int f31594x = 2132021820;

    /* renamed from: y  reason: collision with root package name */
    public static final int f31595y = 2132021822;

    /* renamed from: z  reason: collision with root package name */
    public static final int f31596z = 2132021823;
}
