package od;
/* loaded from: classes2.dex */
public final class b {

    /* renamed from: a */
    public static final int a_res_0x7f0b006d = 2131427437;

    /* renamed from: b  reason: collision with root package name */
    public static final int f31585b = 2131427616;

    /* renamed from: c */
    public static final int c_res_0x7f0b01ac = 2131427756;

    /* renamed from: d */
    public static final int d_res_0x7f0b01ad = 2131427757;

    /* renamed from: e */
    public static final int e_res_0x7f0b01ae = 2131427758;

    /* renamed from: f */
    public static final int f_res_0x7f0b01af = 2131427759;

    /* renamed from: g */
    public static final int g_res_0x7f0b01fb = 2131427835;

    /* renamed from: h */
    public static final int h_res_0x7f0b0336 = 2131428150;

    /* renamed from: i */
    public static final int i_res_0x7f0b0338 = 2131428152;

    /* renamed from: j */
    public static final int j_res_0x7f0b046a = 2131428458;

    /* renamed from: k */
    public static final int k_res_0x7f0b04c0 = 2131428544;

    /* renamed from: l */
    public static final int l_res_0x7f0b073b = 2131429179;

    /* renamed from: m */
    public static final int m_res_0x7f0b0756 = 2131429206;

    /* renamed from: n  reason: collision with root package name */
    public static final int f31586n = 2131429229;

    /* renamed from: o */
    public static final int o_res_0x7f0b0895 = 2131429525;

    /* renamed from: p */
    public static final int p_res_0x7f0b08a5 = 2131429541;
}
