package od;
/* loaded from: classes2.dex */
public final class c {

    /* renamed from: a */
    public static final int a_res_0x7f0e0032 = 2131623986;

    /* renamed from: b */
    public static final int b_res_0x7f0e0047 = 2131624007;

    /* renamed from: c */
    public static final int c_res_0x7f0e004b = 2131624011;

    /* renamed from: d */
    public static final int d_res_0x7f0e006c = 2131624044;

    /* renamed from: e */
    public static final int e_res_0x7f0e00c2 = 2131624130;

    /* renamed from: f */
    public static final int f_res_0x7f0e00e4 = 2131624164;
}
