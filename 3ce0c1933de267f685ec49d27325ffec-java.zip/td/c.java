package td;
/* compiled from: LaserPayCallback.java */
/* loaded from: classes2.dex */
public interface c {
    void a(int i10);

    void b();

    void c();

    void d();
}
