package td;

import android.graphics.drawable.Drawable;
/* compiled from: PayWay.java */
/* loaded from: classes2.dex */
public class d {

    /* renamed from: a  reason: collision with root package name */
    private int f35135a;

    /* renamed from: b  reason: collision with root package name */
    private Drawable f35136b;

    /* renamed from: c  reason: collision with root package name */
    private String f35137c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f35138d = false;

    public Drawable a() {
        return this.f35136b;
    }

    public int b() {
        return this.f35135a;
    }

    public String c() {
        return this.f35137c;
    }

    public boolean d() {
        return this.f35138d;
    }

    public void e(boolean z10) {
        this.f35138d = z10;
    }

    public void f(Drawable drawable) {
        this.f35136b = drawable;
    }

    public void g(int i10) {
        this.f35135a = i10;
    }

    public void h(String str) {
        this.f35137c = str;
    }
}
