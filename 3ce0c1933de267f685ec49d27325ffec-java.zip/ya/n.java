package ya;

import android.content.DialogInterface;
/* loaded from: classes3.dex */
public final /* synthetic */ class n implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ n f36893a = new n();

    private /* synthetic */ n() {
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i10) {
        v.R0(dialogInterface, i10);
    }
}
