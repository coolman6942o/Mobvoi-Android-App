package t7;

import android.graphics.Typeface;
/* compiled from: TextAppearanceFontCallback.java */
/* loaded from: classes.dex */
public abstract class f {
    public abstract void a(int i10);

    public abstract void b(Typeface typeface, boolean z10);
}
