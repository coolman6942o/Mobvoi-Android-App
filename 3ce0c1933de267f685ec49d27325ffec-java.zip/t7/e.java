package t7;
/* compiled from: TextAppearanceConfig.java */
@Deprecated
/* loaded from: classes.dex */
public class e {

    /* renamed from: a  reason: collision with root package name */
    private static boolean f35087a;

    public static boolean a() {
        return f35087a;
    }
}
