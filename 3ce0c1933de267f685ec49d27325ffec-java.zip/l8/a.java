package l8;

import com.google.zxing.common.b;
import com.google.zxing.i;
import o8.c;
/* compiled from: AztecDetectorResult.java */
/* loaded from: classes.dex */
public final class a extends c {

    /* renamed from: c  reason: collision with root package name */
    private final boolean f30436c;

    /* renamed from: d  reason: collision with root package name */
    private final int f30437d;

    /* renamed from: e  reason: collision with root package name */
    private final int f30438e;

    public a(b bVar, i[] iVarArr, boolean z10, int i10, int i11) {
        super(bVar, iVarArr);
        this.f30436c = z10;
        this.f30437d = i10;
        this.f30438e = i11;
    }

    public int c() {
        return this.f30437d;
    }

    public int d() {
        return this.f30438e;
    }

    public boolean e() {
        return this.f30436c;
    }
}
