package p4;
/* compiled from: GifFrame.java */
/* loaded from: classes.dex */
class b {

    /* renamed from: a  reason: collision with root package name */
    int f32561a;

    /* renamed from: b  reason: collision with root package name */
    int f32562b;

    /* renamed from: c  reason: collision with root package name */
    int f32563c;

    /* renamed from: d  reason: collision with root package name */
    int f32564d;

    /* renamed from: e  reason: collision with root package name */
    boolean f32565e;

    /* renamed from: f  reason: collision with root package name */
    boolean f32566f;

    /* renamed from: g  reason: collision with root package name */
    int f32567g;

    /* renamed from: h  reason: collision with root package name */
    int f32568h;

    /* renamed from: i  reason: collision with root package name */
    int f32569i;

    /* renamed from: j  reason: collision with root package name */
    int f32570j;

    /* renamed from: k  reason: collision with root package name */
    int[] f32571k;
}
