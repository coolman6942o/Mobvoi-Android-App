package p4;

import java.util.ArrayList;
import java.util.List;
/* compiled from: GifHeader.java */
/* loaded from: classes.dex */
public class c {

    /* renamed from: d  reason: collision with root package name */
    b f32575d;

    /* renamed from: f  reason: collision with root package name */
    int f32577f;

    /* renamed from: g  reason: collision with root package name */
    int f32578g;

    /* renamed from: h  reason: collision with root package name */
    boolean f32579h;

    /* renamed from: i  reason: collision with root package name */
    int f32580i;

    /* renamed from: j  reason: collision with root package name */
    int f32581j;

    /* renamed from: k  reason: collision with root package name */
    int f32582k;

    /* renamed from: l  reason: collision with root package name */
    int f32583l;

    /* renamed from: m  reason: collision with root package name */
    int f32584m;

    /* renamed from: a  reason: collision with root package name */
    int[] f32572a = null;

    /* renamed from: b  reason: collision with root package name */
    int f32573b = 0;

    /* renamed from: c  reason: collision with root package name */
    int f32574c = 0;

    /* renamed from: e  reason: collision with root package name */
    final List<b> f32576e = new ArrayList();

    public int a() {
        return this.f32578g;
    }

    public int b() {
        return this.f32574c;
    }

    public int c() {
        return this.f32573b;
    }

    public int d() {
        return this.f32577f;
    }
}
