package ge;
/* loaded from: classes2.dex */
public final class m {

    /* renamed from: A */
    public static final int A_res_0x7f1410a7 = 2132021415;

    /* renamed from: B */
    public static final int B_res_0x7f1410a8 = 2132021416;

    /* renamed from: C */
    public static final int C_res_0x7f1410a9 = 2132021417;

    /* renamed from: a */
    public static final int a_res_0x7f14003b = 2132017211;

    /* renamed from: b  reason: collision with root package name */
    public static final int f27431b = 2132017769;

    /* renamed from: c */
    public static final int c_res_0x7f14039b = 2132018075;

    /* renamed from: d */
    public static final int d_res_0x7f14039c = 2132018076;

    /* renamed from: e */
    public static final int e_res_0x7f14039f = 2132018079;

    /* renamed from: f */
    public static final int f_res_0x7f1403c5 = 2132018117;

    /* renamed from: g */
    public static final int g_res_0x7f1403c6 = 2132018118;

    /* renamed from: h */
    public static final int h_res_0x7f1403c7 = 2132018119;

    /* renamed from: i  reason: collision with root package name */
    public static final int f27432i = 2132018934;

    /* renamed from: j */
    public static final int j_res_0x7f140c30 = 2132020272;

    /* renamed from: k  reason: collision with root package name */
    public static final int f27433k = 2132020338;

    /* renamed from: l  reason: collision with root package name */
    public static final int f27434l = 2132020681;

    /* renamed from: m  reason: collision with root package name */
    public static final int f27435m = 2132020682;

    /* renamed from: n  reason: collision with root package name */
    public static final int f27436n = 2132020683;

    /* renamed from: o */
    public static final int o_res_0x7f140fce = 2132021198;

    /* renamed from: p  reason: collision with root package name */
    public static final int f27437p = 2132021399;

    /* renamed from: q */
    public static final int q_res_0x7f14109a = 2132021402;

    /* renamed from: r */
    public static final int r_res_0x7f14109b = 2132021403;

    /* renamed from: s */
    public static final int s_res_0x7f14109c = 2132021404;

    /* renamed from: t */
    public static final int t_res_0x7f14109d = 2132021405;

    /* renamed from: u */
    public static final int u_res_0x7f14109f = 2132021407;

    /* renamed from: v */
    public static final int v_res_0x7f1410a0 = 2132021408;

    /* renamed from: w  reason: collision with root package name */
    public static final int f27438w = 2132021410;

    /* renamed from: x */
    public static final int x_res_0x7f1410a3 = 2132021411;

    /* renamed from: y */
    public static final int y_res_0x7f1410a4 = 2132021412;

    /* renamed from: z */
    public static final int z_res_0x7f1410a6 = 2132021414;
}
