package ge;

import android.content.DialogInterface;
import com.mobvoi.device.DeviceListFragment;
/* loaded from: classes2.dex */
public final /* synthetic */ class f implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ f f27404a = new f();

    private /* synthetic */ f() {
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i10) {
        DeviceListFragment.B0(dialogInterface, i10);
    }
}
