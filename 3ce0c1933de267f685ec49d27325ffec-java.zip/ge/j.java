package ge;
/* loaded from: classes2.dex */
public final class j {

    /* renamed from: a */
    public static final int a_res_0x7f0801e4 = 2131231204;

    /* renamed from: b */
    public static final int b_res_0x7f0801ea = 2131231210;

    /* renamed from: c */
    public static final int c_res_0x7f0801eb = 2131231211;

    /* renamed from: d  reason: collision with root package name */
    public static final int f27413d = 2131231349;

    /* renamed from: e  reason: collision with root package name */
    public static final int f27414e = 2131231350;

    /* renamed from: f  reason: collision with root package name */
    public static final int f27415f = 2131231351;

    /* renamed from: g  reason: collision with root package name */
    public static final int f27416g = 2131231352;

    /* renamed from: h  reason: collision with root package name */
    public static final int f27417h = 2131231353;

    /* renamed from: i  reason: collision with root package name */
    public static final int f27418i = 2131231354;

    /* renamed from: j  reason: collision with root package name */
    public static final int f27419j = 2131231549;

    /* renamed from: k  reason: collision with root package name */
    public static final int f27420k = 2131231551;

    /* renamed from: l  reason: collision with root package name */
    public static final int f27421l = 2131231552;

    /* renamed from: m  reason: collision with root package name */
    public static final int f27422m = 2131231553;

    /* renamed from: n  reason: collision with root package name */
    public static final int f27423n = 2131231554;

    /* renamed from: o  reason: collision with root package name */
    public static final int f27424o = 2131231555;

    /* renamed from: p  reason: collision with root package name */
    public static final int f27425p = 2131231556;

    /* renamed from: q  reason: collision with root package name */
    public static final int f27426q = 2131231557;

    /* renamed from: r  reason: collision with root package name */
    public static final int f27427r = 2131232164;
}
