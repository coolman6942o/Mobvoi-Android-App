package ge;
/* loaded from: classes2.dex */
public final class k {

    /* renamed from: a */
    public static final int a_res_0x7f0b0122 = 2131427618;

    /* renamed from: b */
    public static final int b_res_0x7f0b016b = 2131427691;

    /* renamed from: c */
    public static final int c_res_0x7f0b0213 = 2131427859;

    /* renamed from: d  reason: collision with root package name */
    public static final int f27428d = 2131427864;

    /* renamed from: e */
    public static final int e_res_0x7f0b0383 = 2131428227;

    /* renamed from: f */
    public static final int f_res_0x7f0b039d = 2131428253;

    /* renamed from: g */
    public static final int g_res_0x7f0b0588 = 2131428744;

    /* renamed from: h  reason: collision with root package name */
    public static final int f27429h = 2131429243;

    /* renamed from: i */
    public static final int i_res_0x7f0b07ec = 2131429356;

    /* renamed from: j */
    public static final int j_res_0x7f0b0809 = 2131429385;

    /* renamed from: k  reason: collision with root package name */
    public static final int f27430k = 2131429547;
}
