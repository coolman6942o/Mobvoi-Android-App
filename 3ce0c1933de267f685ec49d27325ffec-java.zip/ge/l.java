package ge;
/* loaded from: classes2.dex */
public final class l {

    /* renamed from: a */
    public static final int a_res_0x7f0e0036 = 2131623990;

    /* renamed from: b */
    public static final int b_res_0x7f0e00c5 = 2131624133;

    /* renamed from: c */
    public static final int c_res_0x7f0e00c6 = 2131624134;

    /* renamed from: d */
    public static final int d_res_0x7f0e00c7 = 2131624135;

    /* renamed from: e */
    public static final int e_res_0x7f0e00c8 = 2131624136;

    /* renamed from: f */
    public static final int f_res_0x7f0e00c9 = 2131624137;

    /* renamed from: g */
    public static final int g_res_0x7f0e0128 = 2131624232;

    /* renamed from: h */
    public static final int h_res_0x7f0e0132 = 2131624242;
}
