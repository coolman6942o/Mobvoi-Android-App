package ge;

import android.content.DialogInterface;
/* loaded from: classes2.dex */
public final /* synthetic */ class e implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ e f27403a = new e();

    private /* synthetic */ e() {
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i10) {
        dialogInterface.dismiss();
    }
}
