package a6;

import com.google.android.gms.common.api.g;
/* loaded from: classes.dex */
public interface b<T> extends g, Iterable<T> {
    T get(int i10);

    int getCount();
}
