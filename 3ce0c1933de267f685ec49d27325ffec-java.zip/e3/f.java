package e3;

import java.util.List;
import l3.a;
/* compiled from: KeyframeAnimation.java */
/* loaded from: classes.dex */
abstract class f<T> extends a<T, T> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public f(List<? extends a<T>> list) {
        super(list);
    }
}
