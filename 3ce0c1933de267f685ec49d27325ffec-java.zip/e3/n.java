package e3;

import com.airbnb.lottie.model.DocumentData;
import java.util.List;
import l3.a;
/* compiled from: TextKeyframeAnimation.java */
/* loaded from: classes.dex */
public class n extends f<DocumentData> {
    public n(List<a<DocumentData>> list) {
        super(list);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: o */
    public DocumentData i(a<DocumentData> aVar, float f10) {
        return aVar.f30404b;
    }
}
