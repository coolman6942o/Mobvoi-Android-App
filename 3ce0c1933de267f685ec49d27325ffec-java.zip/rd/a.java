package rd;

import h8.c;
/* compiled from: RequestBody.java */
/* loaded from: classes2.dex */
public class a {
    @c("wwid")

    /* renamed from: a  reason: collision with root package name */
    public String f33493a;
    @c("watch_id")

    /* renamed from: b  reason: collision with root package name */
    public String f33494b;

    public a(String str, String str2) {
        this.f33493a = str;
        this.f33494b = str2;
    }
}
