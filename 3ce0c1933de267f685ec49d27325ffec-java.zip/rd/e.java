package rd;

import qe.a;
/* compiled from: SafetyRetrofit.java */
/* loaded from: classes2.dex */
public class e extends a {

    /* renamed from: b  reason: collision with root package name */
    private final d f33500b = (d) this.f33122a.create(d.class);

    @Override // qe.a
    protected String b() {
        return "https://ticwear-account.mobvoi.com";
    }

    public d d() {
        return this.f33500b;
    }
}
