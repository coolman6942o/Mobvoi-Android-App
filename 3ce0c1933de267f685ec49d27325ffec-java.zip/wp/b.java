package wp;

import rx.f;
import yp.a;
/* compiled from: RxAndroidSchedulersHook.java */
/* loaded from: classes3.dex */
public class b {

    /* renamed from: a  reason: collision with root package name */
    private static final b f36345a = new b();

    public static b a() {
        return f36345a;
    }

    public f b() {
        return null;
    }

    public a c(a aVar) {
        return aVar;
    }
}
