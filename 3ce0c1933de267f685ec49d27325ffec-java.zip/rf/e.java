package rf;

import com.mobvoi.health.common.data.pojo.ActivityType;
import java.util.List;
import qf.c;
/* compiled from: DataSessionDao.java */
/* loaded from: classes2.dex */
public interface e {
    List<c> a(i1.e eVar);

    List<c> b(String str, String str2, ActivityType activityType, long j10, long j11, String str3);

    int c(String str);

    c d(String str);

    int e(c cVar);

    List<c> f(String str, String str2, ActivityType activityType, long j10, long j11);

    long g(c cVar);

    List<c> h(String str, String str2, ActivityType activityType, long j10);
}
