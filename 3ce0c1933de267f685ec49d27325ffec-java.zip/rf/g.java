package rf;

import qf.d;
/* compiled from: DataSourceDao.java */
/* loaded from: classes2.dex */
public interface g {
    long a(d dVar);

    d b(String str);

    d c(String str, String str2);
}
