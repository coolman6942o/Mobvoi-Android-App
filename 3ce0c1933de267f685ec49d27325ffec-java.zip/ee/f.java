package ee;
/* loaded from: classes2.dex */
public final class f {

    /* renamed from: a */
    public static final int a_res_0x7f15051d = 2132083997;

    /* renamed from: b */
    public static final int b_res_0x7f150522 = 2132084002;
}
