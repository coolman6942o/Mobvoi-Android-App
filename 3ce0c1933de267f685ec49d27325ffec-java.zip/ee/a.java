package ee;
/* loaded from: classes2.dex */
public final class a {

    /* renamed from: a */
    public static final int a_res_0x7f06014c = 2131099980;
}
