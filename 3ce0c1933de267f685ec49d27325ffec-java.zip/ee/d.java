package ee;
/* loaded from: classes2.dex */
public final class d {

    /* renamed from: a */
    public static final int a_res_0x7f0e009d = 2131624093;

    /* renamed from: b */
    public static final int b_res_0x7f0e014c = 2131624268;

    /* renamed from: c */
    public static final int c_res_0x7f0e0162 = 2131624290;

    /* renamed from: d */
    public static final int d_res_0x7f0e020f = 2131624463;
}
