package ee;
/* loaded from: classes2.dex */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final int f25885a = 2131231245;

    /* renamed from: b  reason: collision with root package name */
    public static final int f25886b = 2131231246;

    /* renamed from: c  reason: collision with root package name */
    public static final int f25887c = 2131231519;
}
