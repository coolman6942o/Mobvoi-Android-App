package ee;
/* loaded from: classes2.dex */
public final class c {

    /* renamed from: a */
    public static final int a_res_0x7f0b00a6 = 2131427494;

    /* renamed from: b */
    public static final int b_res_0x7f0b02be = 2131428030;

    /* renamed from: c */
    public static final int c_res_0x7f0b02c6 = 2131428038;

    /* renamed from: d */
    public static final int d_res_0x7f0b05b6 = 2131428790;

    /* renamed from: e */
    public static final int e_res_0x7f0b060b = 2131428875;

    /* renamed from: f */
    public static final int f_res_0x7f0b060c = 2131428876;

    /* renamed from: g */
    public static final int g_res_0x7f0b06ca = 2131429066;

    /* renamed from: h  reason: collision with root package name */
    public static final int f25888h = 2131429243;

    /* renamed from: i */
    public static final int i_res_0x7f0b07c2 = 2131429314;

    /* renamed from: j */
    public static final int j_res_0x7f0b07c3 = 2131429315;

    /* renamed from: k */
    public static final int k_res_0x7f0b07d7 = 2131429335;

    /* renamed from: l  reason: collision with root package name */
    public static final int f25889l = 2131429477;
}
